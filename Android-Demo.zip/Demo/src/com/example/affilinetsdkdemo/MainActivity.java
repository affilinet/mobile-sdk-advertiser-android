package com.example.affilinetsdkdemo;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import com.rm.affilinet.SessionCallback;
import com.rm.affilinet.advertiser.*;
import com.rm.affilinet.communication.*;
import com.rm.affilinet.models.*;
import com.rm.affilinet.retargeting.AddToCartTagging;
import com.rm.affilinet.retargeting.CategoryViewTagging;
import com.rm.affilinet.retargeting.CheckoutTagging;
import com.rm.affilinet.retargeting.LandingpageTagging;
import com.rm.affilinet.retargeting.ProductViewTagging;
import com.rm.affilinet.retargeting.SearchPageTagging;
import com.rm.affilinet.tracking.*;

import android.os.Bundle;
import android.app.Activity;
import android.app.ProgressDialog;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class MainActivity extends Activity {
	
	private ProgressDialog progress;
	
	class LocalSessionCallback implements SessionCallback {
		
		@Override
		public void onRequestsFinished() {
			Log.v("affilinet", "Finished all requests in Session");
			hideProgressDialog();
			
		}

		@Override
		public void onRequestsError(Error error) {
			Log.v("affilinet", "Failed requests in Session: " + error.getMessage());
			hideProgressDialog();
		}

		@Override
		public void onRequestResponse(Request request, RequestResponse response) {
			if(response.error != null)
				Log.v("affilinet", "Request Completed With Error: " + response.error.getMessage());
			else 
				Log.v("affilinet", "Request Completed");
		}
		
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		runAdvertiserTests();
	}
	
	private void runAdvertiserTests() {
		setContentView(R.layout.activity_main);
		
		Account account = new AdvertiserAccount(12452);
		Session session = Session.getInstance();
		try {
			session.open(getApplicationContext(), account, CountryCode.GERMANY);
		} catch (Exception e) {
			Log.v("affilinet", e.getMessage());
		}
		
		final ListView listview = (ListView) findViewById(R.id.main_menu_list_view);
		String[] values = new String[] {"Transaction Order Tracking", "Basket Order Tracking", "App Download Tracking",
				"Product View Tagging", "Travel Product View Tagging", "Dating Product View Tagging", "Add To Cart Tagging", 
				"Checkout Tagging", "Category View Tagging", "Landingpage Tagging", "Search Page Tagging"};
		
		final ArrayList<String> list = new ArrayList<String>();
		for(int i = 0; i < values.length; i++) {
			list.add(values[i]);
		}
		
		final ArrayAdapter adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, list);
		listview.setAdapter(adapter);
		listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, final View view, int position, long id) {
				switch (position) {
				case 0:
					runTransactionOrderTracking();
					break;
				case 1:
					runBasketTracking();
					break;
				case 2:
					runAppDownloadTracking();
					break;
				case 3:
					runProductViewTagging();
					break;
				case 4:
					runTravelProductTagging();
					break;
				case 5:
					runDatingProductTagging();
					break;
				case 6:
					runAddToCartTagging();
					break;
				case 7:
					runCheckoutTagging();
					break;
				case 8:
					runCategoryTagging();
					break;
				case 9:
					runLandingpageTagging();
					break;
				case 10:
					runSearchTagging();
					break;
				default:
					break;
				}
			}
			
		});
		
	}
	
	private void runTransactionOrderTracking() {
		TransactionOrderTracking orderTracking = new TransactionOrderTracking(Session.getInstance());
		orderTracking.protocol = Protocol.HTTP;
		orderTracking.setCurrencyCode(CurrencyCode.EURO);
		orderTracking.setMediaNumber(12234);
		orderTracking.setMediaType(OTMediaType.GraphicBanner);
		orderTracking.setOrderId(UUID.randomUUID().toString());
		
		OTOrderRate orderRate = new OTOrderRate();
		orderRate.rateMode = OTRateMode.SALE;
		orderRate.rateNumber = 1;
		orderTracking.setOrderRate(orderRate);
		orderTracking.setOrderValue(400);
		orderTracking.setVoucherCode("dasd");
		
		this.executeRequest(orderTracking);
	}
	
	private void runBasketTracking() {
		BasketOrderTracking basketTracking = new BasketOrderTracking(Session.getInstance());
		basketTracking.protocol = Protocol.HTTP;
		basketTracking.setCurrencyCode(CurrencyCode.EURO);
		basketTracking.setMediaNumber(12234);
		basketTracking.setMediaType(OTMediaType.HTMLBanner);
		basketTracking.setOrderId("Android-Basket-e1beba34-14a6-4384-9cb8-1efd8ceb1cee");
		basketTracking.setVoucherCode("vCodeeeeeee");
		
		OTBasketItem basketItem = new OTBasketItem();
		basketItem.articleNumber = "ANNNS";
		basketItem.productName = "amazing product";
		basketItem.category = "jeans";
		basketItem.brand = "Versace";
		basketItem.quantity = 1;
		basketItem.singlePrice = 200.45;
		
		OTBasketItem basketItem2 = new OTBasketItem();
		basketItem2.articleNumber = "ANNNS2";
		basketItem2.productName = "amazing product 2";
		basketItem2.category = "jeans 2";
		basketItem2.brand = "Versace 2";
		basketItem2.quantity = 1;
		basketItem2.singlePrice = 400.45;
		
		OTBasketItem basketItem3 = new OTBasketItem();
		basketItem3.articleNumber = "ANNNS3";
		basketItem3.productName = "amazing product 3";
		basketItem3.category = "jeans 3";
		basketItem3.brand = "Versace 3";
		basketItem3.quantity = 3;
		basketItem3.singlePrice = 400.45;
		
		basketTracking.addBasketItem(basketItem);
		basketTracking.addBasketItem(basketItem2);
		basketTracking.addBasketItem(basketItem3);
		
		this.executeRequest(basketTracking);
	}
	
	private void runAppDownloadTracking() {
		AppDownloadTracking downloadTracking = new AppDownloadTracking(Session.getInstance());
		downloadTracking.protocol = Protocol.HTTP;
		downloadTracking.setRateNumber(1);
		this.executeRequest(downloadTracking);
	}
	
	private void runProductViewTagging() {
		RTProduct product = new RTProduct();
		product.productId = UUID.randomUUID().toString();
		product.name = "Amazing Product";
		product.price = 40.45;
		product.oldPrice = 42.99;
		product.category = new RTProductCategory();
		product.category.pathItems = new ArrayList<String>();
		product.category.pathItems.add("path");
		product.category.pathItems.add("to");
		product.category.pathItems.add("category");
		product.category.clickURL = "http://category-click-url.com";
		product.category.imageURL = "http://category-image-url.com";
		product.brand = "Amazing Brand";
		product.inStock = true;
		product.rating = 7;
		product.onSale = true;
		product.accessory = false;
		product.clickURL = "http://product-click-url.com";
		product.imageURL = "http://product-image-url.com";
		
		
		ProductViewTagging productTagging = new ProductViewTagging(Session.getInstance(), product);
		productTagging.currency = CurrencyCode.EURO;
		this.executeRequest(productTagging);
	}
	
	private void runTravelProductTagging() {
		RTTravelProduct product = new RTTravelProduct();
		product.productId = UUID.randomUUID().toString();
		product.name = "Amazing Product";
		product.price = 40.45;
		product.oldPrice = 42.99;
		product.category = new RTProductCategory();
		product.category.pathItems = new ArrayList<String>();
		product.category.pathItems.add("path");
		product.category.pathItems.add("to");
		product.category.pathItems.add("category");
		product.category.clickURL = "http://category-click-url.com";
		product.category.imageURL = "http://category-image-url.com";
		product.brand = "Amazing Brand";
		product.inStock = true;
		product.rating = 7;
		product.onSale = true;
		product.accessory = false;
		product.clickURL = "http://product-click-url.com";
		product.imageURL = "http://product-image-url.com";
		product.departureDate = new Date(113, 11, 5, 11, 25); // 0 is 1900
		product.endDate = new Date(113, 11, 5, 14, 25);
		product.productType = "with hotel";
		product.kids = false;
		product.numberOfAdults = 2;
		product.hotelCategory = "middle";
		product.pointOfDeparture = "Lisbon";
		product.pointOfDestination = "Frankfurt";
		
		
		ProductViewTagging productTagging = new ProductViewTagging(Session.getInstance(), product);
		productTagging.currency = CurrencyCode.EURO;
		this.executeRequest(productTagging);
		
	}
	
	private void runDatingProductTagging() {
		RTDatingProduct product = new RTDatingProduct();
		product.productId = UUID.randomUUID().toString();
		product.name = "Amazing Product";
		product.price = 40.45;
		product.oldPrice = 42.99;
		product.category = new RTProductCategory();
		product.category.pathItems = new ArrayList<String>();
		product.category.pathItems.add("path");
		product.category.pathItems.add("to");
		product.category.pathItems.add("category");
		product.category.clickURL = "http://category-click-url.com";
		product.category.imageURL = "http://category-image-url.com";
		product.brand = "Amazing Brand";
		product.inStock = true;
		product.rating = 7;
		product.onSale = true;
		product.accessory = false;
		product.clickURL = "http://product-click-url.com";
		product.imageURL = "http://product-image-url.com";
		product.customer = new RTDatingCustomer();
		product.customer.gender = "Male";
		product.customer.ageRange = "18-25";
		product.customer.zipCode = "60329";
		product.customer.wasLoggedIn = false;
		
		ProductViewTagging productTagging = new ProductViewTagging(Session.getInstance(), product);
		productTagging.currency = CurrencyCode.EURO;
		this.executeRequest(productTagging);
	}
	
	private void runAddToCartTagging() {
		RTProduct product = new RTProduct();
		product.productId = UUID.randomUUID().toString();
		product.name = "Amazing Product";
		product.price = 40.45;
		product.oldPrice = 42.99;
		product.category = new RTProductCategory();
		product.category.pathItems = new ArrayList<String>();
		product.category.pathItems.add("path");
		product.category.pathItems.add("to");
		product.category.pathItems.add("category");
		product.category.clickURL = "http://category-click-url.com";
		product.category.imageURL = "http://category-image-url.com";
		product.brand = "Amazing Brand";
		product.inStock = true;
		product.rating = 7;
		product.onSale = true;
		product.accessory = false;
		product.clickURL = "http://product-click-url.com";
		product.imageURL = "http://product-image-url.com";
		
		RTOrderItem item1 = new RTOrderItem();
		item1.quantity = 2;
		item1.product = product;
		
		RTTravelProduct travelProduct = new RTTravelProduct();
		travelProduct.productId = UUID.randomUUID().toString();
		travelProduct.name = "Amazing Product";
		travelProduct.price = 30.45;
		travelProduct.oldPrice = 32.99;
		travelProduct.category = new RTProductCategory();
		travelProduct.category.pathItems = new ArrayList<String>();
		travelProduct.category.pathItems.add("path");
		travelProduct.category.pathItems.add("to");
		travelProduct.category.pathItems.add("category");
		travelProduct.category.clickURL = "http://category-click-url.com";
		travelProduct.category.imageURL = "http://category-image-url.com";
		travelProduct.brand = "Amazing Brand";
		travelProduct.inStock = true;
		travelProduct.rating = 7;
		travelProduct.onSale = true;
		travelProduct.accessory = false;
		travelProduct.clickURL = "http://product-click-url.com";
		travelProduct.imageURL = "http://product-image-url.com";
		travelProduct.departureDate = new Date(113, 11, 5, 11, 25);
		travelProduct.endDate = new Date(113, 11, 5, 14, 25);
		travelProduct.productType = "with hotel";
		travelProduct.kids = false;
		travelProduct.numberOfAdults = 2;
		travelProduct.hotelCategory = "middle";
		travelProduct.pointOfDeparture = "Lisbon";
		travelProduct.pointOfDestination = "Frankfurt";
		
		RTOrderItem item2 = new RTOrderItem();
		item2.quantity = 1;
		item2.product = travelProduct;
		
		RTDatingProduct datingProduct = new RTDatingProduct();
		datingProduct.productId = UUID.randomUUID().toString();
		datingProduct.name = "Amazing Product";
		datingProduct.price = 40.45;
		datingProduct.oldPrice = 42.99;
		datingProduct.category = new RTProductCategory();
		datingProduct.category.pathItems = new ArrayList<String>();
		datingProduct.category.pathItems.add("path");
		datingProduct.category.pathItems.add("to");
		datingProduct.category.pathItems.add("category");
		datingProduct.category.clickURL = "http://category-click-url.com";
		datingProduct.category.imageURL = "http://category-image-url.com";
		datingProduct.brand = "Amazing Brand";
		datingProduct.inStock = true;
		datingProduct.rating = 7;
		datingProduct.onSale = true;
		datingProduct.accessory = false;
		datingProduct.clickURL = "http://product-click-url.com";
		datingProduct.imageURL = "http://product-image-url.com";
		datingProduct.customer = new RTDatingCustomer();
		datingProduct.customer.gender = "Male";
		datingProduct.customer.ageRange = "18-25";
		datingProduct.customer.zipCode = "60329";
		datingProduct.customer.wasLoggedIn = false;
		
		RTOrderItem item3 = new RTOrderItem();
		item3.quantity = 1;
		item3.product = datingProduct;
		
		List<RTOrderItem> items = new ArrayList<RTOrderItem>();
		items.add(item1);
		items.add(item2);
		items.add(item3);
		
		AddToCartTagging addToCartTagging = new AddToCartTagging(Session.getInstance(), items);
		addToCartTagging.currency = CurrencyCode.EURO;
		this.executeRequest(addToCartTagging);
	}
	
	private void runCheckoutTagging() {
		RTOrder order = new RTOrder();
		order.orderId = UUID.randomUUID().toString();
		order.total = 324.45;
		order.items = new ArrayList<RTOrderItem>();
		
		RTProduct product = new RTProduct();
		product.productId = UUID.randomUUID().toString();
		product.name = "Amazing Product";
		product.price = 40.45;
		product.oldPrice = 42.99;
		product.category = new RTProductCategory();
		product.category.pathItems = new ArrayList<String>();
		product.category.pathItems.add("path");
		product.category.pathItems.add("to");
		product.category.pathItems.add("category");
		product.category.clickURL = "http://category-click-url.com";
		product.category.imageURL = "http://category-image-url.com";
		product.brand = "Amazing Brand";
		product.inStock = true;
		product.rating = 7;
		product.onSale = true;
		product.accessory = false;
		product.clickURL = "http://product-click-url.com";
		product.imageURL = "http://product-image-url.com";
		
		RTOrderItem item1 = new RTOrderItem();
		item1.quantity = 2;
		item1.product = product;
		
		RTTravelProduct travelProduct = new RTTravelProduct();
		travelProduct.productId = UUID.randomUUID().toString();
		travelProduct.name = "Amazing Travel Product";
		travelProduct.price = 30.45;
		travelProduct.oldPrice = 32.99;
		travelProduct.category = new RTProductCategory();
		travelProduct.category.pathItems = new ArrayList<String>();
		travelProduct.category.pathItems.add("path");
		travelProduct.category.pathItems.add("to");
		travelProduct.category.pathItems.add("category");
		travelProduct.category.clickURL = "http://category-click-url.com";
		travelProduct.category.imageURL = "http://category-image-url.com";
		travelProduct.brand = "Amazing Travel Brand";
		travelProduct.inStock = true;
		travelProduct.rating = 7;
		travelProduct.onSale = true;
		travelProduct.accessory = false;
		travelProduct.clickURL = "http://product-click-url.com";
		travelProduct.imageURL = "http://product-image-url.com";
		travelProduct.departureDate = new Date(113, 11, 5, 11, 25);
		travelProduct.endDate = new Date(113, 11, 5, 14, 25);
		travelProduct.productType = "with hotel";
		travelProduct.kids = false;
		travelProduct.numberOfAdults = 2;
		travelProduct.hotelCategory = "middle";
		travelProduct.pointOfDeparture = "Lisbon";
		travelProduct.pointOfDestination = "Frankfurt";
		
		RTOrderItem item2 = new RTOrderItem();
		item2.quantity = 1;
		item2.product = travelProduct;
		
		RTDatingProduct datingProduct = new RTDatingProduct();
		datingProduct.productId = UUID.randomUUID().toString();
		datingProduct.name = "Amazing Dating Product";
		datingProduct.price = 234.45;
		datingProduct.oldPrice = 444.99;
		datingProduct.category = new RTProductCategory();
		datingProduct.category.pathItems = new ArrayList<String>();
		datingProduct.category.pathItems.add("path");
		datingProduct.category.pathItems.add("to");
		datingProduct.category.pathItems.add("category");
		datingProduct.category.clickURL = "http://category-click-url.com";
		datingProduct.category.imageURL = "http://category-image-url.com";
		datingProduct.brand = "Amazing Dating Brand";
		datingProduct.inStock = true;
		datingProduct.rating = 7;
		datingProduct.onSale = true;
		datingProduct.accessory = false;
		datingProduct.clickURL = "http://product-click-url.com";
		datingProduct.imageURL = "http://product-image-url.com";
		datingProduct.customer = new RTDatingCustomer();
		datingProduct.customer.gender = "Male";
		datingProduct.customer.ageRange = "18-25";
		datingProduct.customer.zipCode = "60329";
		datingProduct.customer.wasLoggedIn = false;
		
		RTOrderItem item3 = new RTOrderItem();
		item3.quantity = 1;
		item3.product = datingProduct;
		
		order.items.add(item1);
		order.items.add(item2);
		order.items.add(item3);
		
		CheckoutTagging checkoutTagging = new CheckoutTagging(Session.getInstance(), order);
		checkoutTagging.currency = CurrencyCode.EURO;
		this.executeRequest(checkoutTagging);
	}
	
	private void runCategoryTagging() {
		RTProductCategory productCategory = new RTProductCategory();
		productCategory.clickURL = "http://category-clickurl.com";
		productCategory.imageURL = "http://category-imageurl.com";
		productCategory.pathItems = new ArrayList<String>();
		productCategory.pathItems.add("path");
		productCategory.pathItems.add("to");
		productCategory.pathItems.add("category");
		
		CategoryViewTagging categoryTagging = new CategoryViewTagging(Session.getInstance(), productCategory);
		this.executeRequest(categoryTagging);
	}

	private void runLandingpageTagging() {
		LandingpageTagging landingpageTagging = new LandingpageTagging(Session.getInstance());
		this.executeRequest(landingpageTagging);
	}
	
	private void runSearchTagging() {
		RTProduct product = new RTProduct();
		product.productId = UUID.randomUUID().toString();
		
		List<RTProduct> products = new ArrayList<RTProduct>();
		products.add(product);
		
		SearchPageTagging searchTagging = new SearchPageTagging(Session.getInstance(), "Search Term", products);
		this.executeRequest(searchTagging);
	}
	
	private void executeRequest(Request request) {
		List<Request> requests = new ArrayList<Request>();
		requests.add(request);
		try {
			this.showProgressDialog();
			Session.getInstance().executeRequests(requests, new LocalSessionCallback());
		} catch (Exception e) {
			Log.v("affilinet", e.getMessage());
		}
	}

	private void showProgressDialog() {
		if(this.progress == null) {
			this.progress = new ProgressDialog(this);
			progress.setTitle("Loading");
			progress.setMessage("Wait while loading...");
		}
		progress.show();
	}
	
	private void hideProgressDialog() {
		progress.dismiss();
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

}
